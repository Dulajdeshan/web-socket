export const firebaseConfig = {
    apiKey: "AIzaSyB-ZT_nFUNw_KCJLCDg5yZvYkaExIB1JKg",
    authDomain: "strangrz.firebaseapp.com",
    databaseURL: "https://strangrz.firebaseio.com",
    projectId: "strangrz",
    storageBucket: "strangrz.appspot.com",
    messagingSenderId: "393601861325",
    appId: "1:393601861325:web:e423ed8916bb446e790b84"
};
